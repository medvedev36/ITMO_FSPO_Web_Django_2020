import React from "react";

export const NavBar = () => {
   return (
       <nav className="navbar navbar-dark sticky-top bg-dark">
            <a className="navbar-brand" href="/">Carsharing</a>

        </nav>) 
}